#import "jmeAppDelegate.h"

@interface jmeAppDelegate_iPad : jmeAppDelegate

@end
