#import "jmeAppDelegate.h"

@interface jmeAppDelegate_iPhone : jmeAppDelegate

@end
